# Global Count Trading Platform

A comprehensive trading, matrix contribution, and betting platform called "Global Count Trading" - "No Lost No Regrets"

## Features Implemented

### 🏠 Landing Page
- Professional landing page with company information
- Display of all contribution plans (₦10,000 to ₦600,000)
- Legal license and trademark information
- Business owner: Olawale Abdul-Ganiyu
- Email: adeganglobal@gmail.com

### 👤 Customer Dashboard
- **Registration System**: 10-digit account number generation
- **Authentication**: Secure login with admin/customer separation
- **Matrix Contribution**: 
  - 11-person matrix pool system
  - Multiple investment tiers (10k-600k)
  - Automatic position rotation
  - Pool progress visualization
- **Payment Systems**:
  - Web pay (card payments)
  - Bank transfer with receipt upload
  - Crypto wallet (Bitcoin, Ethereum, USDT)
  - Mobile wallets (OPay, Moniepoint, PalmPay)
- **Withdrawal System**:
  - Support for commercial banks
  - Microfinance banks
  - Mobile wallet transfers
  - Minimum withdrawal: ₦1,000
- **Auto-Reinvest**: Option for automatic reinvestment
- **Transaction History**: Complete record with charge breakdowns
- **Notifications**: Email and phone alerts for all transactions

### 🎯 Sports Betting & Casino
- **Sports Betting**: Football, basketball, tennis, virtual games
- **Bet Slip**: Multiple selection support with odds calculation
- **Casino Games**: Slots, roulette, blackjack, poker
- **Betting Integration**: Connected to main account balance

### 🔐 Admin Panel
- **User Management**: Approve, block, edit user profiles
- **Document Verification**: Passport and ID document review
- **Banking Operations**: 
  - Send money to local/international banks
  - SWIFT transfers
  - Crypto transfers
  - Swiss banking integration
- **Withdrawal Processing**: Approve/reject withdrawal requests
- **Balance Management**: Credit/debit user accounts
- **Matrix Monitoring**: Real-time view of all matrix pools
- **Message System**: Respond to user inquiries
- **Transaction Monitoring**: Full oversight of all platform transactions

### 💰 Charge System (10% Breakdown)
When a user receives payout, the following charges are deducted:
- Monitoring Fee: ₦5,000
- Web Maintenance: ₦1,000
- Administrative: ₦1,000
- Current Account: ₦1,000
- Transactions: ₦1,000
- Robot: ₦500
- VAT: ₦1,000
- **Total Charges: ₦10,500**

### 📋 Matrix System Logic
1. Users join matrix by contributing (₦10k-₦600k)
2. Matrix fills up to 11 people
3. When 11th person joins:
   - 11th person's contribution goes to admin balance
   - First person receives payout from 10 people's contributions (minus 10% charges)
   - Charges are credited to admin balance
   - Matrix rotates: 1st person leaves, 2nd becomes 1st, 3rd becomes 2nd, etc.
4. Users can auto-reinvest or manually reinvest

### 📄 Legal Documents
- Gaming License (Worldwide operation)
- Business Registration Certificate
- Trademark Registration
- Terms and Conditions
- Owner: Olawale Abdul-Ganiyu

## System Architecture

### File Structure
```
/workspace/
├── index.html          # Main application interface
├── styles.css          # Complete styling system
├── script.js           # All JavaScript functionality
├── README.md           # This file
└── todo.md            # Development tracking
```

### Technologies Used
- **HTML5**: Structure and semantics
- **CSS3**: Modern styling with gradients, animations, and responsive design
- **JavaScript (ES6+)**: All application logic
- **LocalStorage**: Data persistence

### Data Storage
All data is stored in browser localStorage:
- Users database
- Matrix pools
- Transactions
- Admin balance
- Messages
- Withdrawal requests
- Notifications

## How to Use

### For Customers

1. **Registration**:
   - Click "Register" on landing page
   - Fill in personal details
   - Upload passport photo and ID document
   - Receive 10-digit account number
   - Wait for admin approval

2. **Login**:
   - Enter 10-digit account number
   - Enter password
   - Access customer dashboard

3. **Deposit Funds**:
   - Go to "Deposit" section
   - Choose payment method (Card, Bank, Crypto, Wallet)
   - Enter amount
   - Upload receipt (for bank/wallet)
   - Wait for admin verification

4. **Join Matrix**:
   - Go to "Contribute" section
   - Select investment plan (₦10k-₦600k)
   - Confirm contribution
   - Track progress in "Matrix Pool" section

5. **Withdraw**:
   - Go to "Withdraw" section
   - Enter amount (minimum ₦1,000)
   - Select bank/wallet
   - Enter account details
   - Wait for admin approval

6. **Sports Betting**:
   - Go to "Sports Betting" section
   - Select sport
   - Add selections to bet slip
   - Enter stake amount
   - Place bet

### For Admins

1. **Login**:
   - Check "Admin Login" checkbox
   - Enter admin credentials
   - Enter admin key: GCT2024

2. **Approve Users**:
   - Go to "Approvals" section
   - Review user documents
   - Approve or reject registration

3. **Manage Users**:
   - Go to "User Management"
   - View all users
   - Block/unblock accounts
   - Edit user balances

4. **Process Withdrawals**:
   - Go to "Withdrawals" section
   - Review withdrawal requests
   - Approve or reject
   - System automatically handles balance updates

5. **Banking Operations**:
   - Go to "Banking" section
   - Send money to banks (local/international/SWIFT/crypto)
   - View banking details for receiving funds

6. **Monitor Matrix**:
   - Go to "Matrix Monitor" section
   - View all active matrix pools
   - Track member positions
   - Monitor pool progress

## Security Features

### Customer vs Admin Separation
- Separate login systems
- Admin key required for admin access
- Customers cannot access admin panel
- Admin has full oversight of customer accounts

### Account Security
- 10-digit account numbers
- Password authentication
- Account status management (active, pending, blocked)
- Document verification required

### Transaction Security
- All transactions logged
- Withdrawal approval system
- Balance verification before transactions
- Minimum balance requirements

## Matrix Calculation Example

**Scenario**: 11 people each contribute ₦100,000

**Process**:
1. 11th person contributes ₦100,000 → Admin balance
2. First person receives: (10 × ₦100,000) - ₦10,500 = ₦989,500
3. Admin receives: ₦100,000 + ₦10,500 = ₦110,500

**Charges Breakdown**:
- Monitoring Fee: ₦5,000
- Web Maintenance: ₦1,000
- Administrative: ₦1,000
- Current Account: ₦1,000
- Transactions: ₦1,000
- Robot: ₦500
- VAT: ₦1,000
- **Total**: ₦10,500

## Contribution Plans

| Plan | Amount | Potential Return |
|------|--------|------------------|
| Starter | ₦10,000 | ₦81,000 |
| Bronze | ₦100,000 | ₦989,500 |
| Silver | ₦200,000 | ₦1,989,500 |
| Gold | ₦300,000 | ₦2,989,500 |
| Platinum | ₦400,000 | ₦3,989,500 |
| Diamond | ₦500,000 | ₦4,989,500 |
| VIP | ₦600,000 | ₦5,989,500 |

*Note: Potential return = (10 × contribution) - charges*

## Responsive Design

The platform is fully responsive and works on:
- Desktop computers
- Tablets
- Mobile phones

## Browser Compatibility

- Chrome (recommended)
- Firefox
- Safari
- Edge
- Opera

## Legal Information

**Company**: Global Count Trading  
**Slogan**: No Lost No Regrets  
**Owner**: Olawale Abdul-Ganiyu  
**Email**: adeganglobal@gmail.com  
**Gaming License**: GCT-2024-WW-001  
**Trademark**: TM-2024-GCT-001  
**Registration**: RC-2024-789456  

## Notes

- This is a demonstration/prototype platform
- Uses localStorage for data persistence (data stored in browser)
- For production use, implement:
  - Backend server with database
  - Real payment gateways
  - Email/SMS notification services
  - Secure authentication with JWT
  - HTTPS encryption
  - Regulatory compliance

## Support

For issues or questions, contact: adeganglobal@gmail.com

---

**⚠️ Disclaimer**: This is a software demonstration. Real-money trading, betting, and matrix systems require proper licensing, regulatory approval, and legal compliance in your jurisdiction.